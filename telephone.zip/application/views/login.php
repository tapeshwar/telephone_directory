<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Log in</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?=base_url('asset/css/icheck-bootstrap.min.css')?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url('asset/css/custom.css')?>">
  <style>
  label.error, span.error, div.error { font-size: 12px; color:#FB3A3A; font-weight: normal;}
lable {display: inline-block; max-width: 100%;}
.form-control{width: 100%;}
  </style>
</head>
<body class="hold-transition login-page">





<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <span class="h1"><b>Admin</b></span>
      <div id="error" style="color:red"></div>
      
    </div>
    <div class="card-body">
      <p class="login-box-msg">Sign In</p>

      <form method="post" id="user_login_form" data-url="<?=base_url('login/user_login')?>">
        <div class="form-group mb-3">
          <input type="text" class="form-control" placeholder="Username" name="username" required data-msg-required="Username required"/>
          <!-- <div class="input-group-append">
            <div class="input-group-text">
              <span class="fa fa-user"></span>
            </div>
          </div> -->
        </div>
        <div class="form-group mb-3">
          <input type="password" class="form-control" placeholder="Password"name="password" required data-msg-required="Password required"/>
          <!-- <div class="input-group-append">
            <div class="input-group-text">
              <span class="fa fa-key"></span>
            </div>
          </div> -->
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block user_login_btn"><span class="fa fa-lock"></span> Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?=base_url('asset/js/jquery.min.js')?>"></script>
<!-- Bootstrap 4 -->
<script src="<?=base_url('asset/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?=base_url('asset/js/jquery.validate.js')?>"></script>

<!-- Custom App JS -->
<script src="<?=base_url('asset/js/custom.js')?>"></script>
<script src="<?=base_url('asset/js/myscript.js')?>"></script>
</body>
</html>
