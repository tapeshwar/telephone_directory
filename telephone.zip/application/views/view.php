<?php $this->load->view('common/header.php'); ?>
 
 <?php $this->load->view('common/sidebar.php'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>View Contact <a href="<?=base_url('contact')?>" class="btn btn-sm btn-primary"> <i class="fa fa-file-text" aria-hidden="true"></i> View All</a></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">View Contact</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content row">

    <div class="col-md-6">
      <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">View Contact</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="contact_edit" method="post" action="<?=base_url('contact/update')?>" enctype="multipart/form-data" required>
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="inputFirstName">First Name: </label>
                    <?=(!empty($contact['first_name'])) ? $contact['first_name'] : '' ?>
                  </div>
            

                
                  <div class="form-group">
                    <label for="inputMiddleName">Middle Name: </label>
                    <?=(!empty($contact['middle_name'])) ? $contact['middle_name'] : '' ?>
                  </div>
               
               
                  <div class="form-group">
                    <label for="inputLastName">Last Name: </label>
                    <?=(!empty($contact['last_name'])) ? $contact['last_name'] : '' ?>
                  </div>
                
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address: </label>
                    <?=(!empty($contact['email'])) ? $contact['email'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Mobile: </label>
                    <?=(!empty($contact['mobile'])) ? $contact['mobile'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Landline: </label>
                    <?=(!empty($contact['landline'])) ? $contact['landline'] : '' ?>
                  </div>


                  <div class="form-group">
                    <label for="inputPhoto">Photo: </label>
                    <?php if(!empty($contact['photo'])) {?>
                    <span><img src="<?=base_url('asset/photo/'.$contact['photo'])?>" height="50" alt="Photo"></span>
                  <?php } ?>
                  </div>
                

                  <div class="form-group">
                    <label for="inputNotes">Notes: </label>
                    <?=(!empty($contact['notes'])) ? $contact['notes'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Added Date: </label>
                    <?=(!empty($contact['added_date'])) ? $contact['added_date'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Updated Date: </label>
                    <?=(!empty($contact['updated_date'])) ? $contact['updated_date'] : '' ?>
                  </div>

                
                </div>
                <!-- /.card-body -->

               
              </form>
            </div>
      <!-- /.card -->
    </div>

    <div class="col-lg-6">
            <div class="card">
              <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                  <h3 class="card-title">Total Number of Views: <?=(!empty($contact['no_of_viewed']+1)) ? $contact['no_of_viewed']+1 : 0 ?> </h3>
                </div>
              </div>
              <div class="card-body">
                <div class="d-flex">
                 
                
                </div>
                <!-- /.d-flex -->

                <div class="position-relative mb-4">
                  <canvas id="view-chart-single" height="200"></canvas>
                </div>

                <div class="d-flex flex-row justify-content-end">
                  <span class="mr-2">
                    <i class="fa fa-square text-primary"></i> Last 7 Days
                  </span>

                 
                </div>
              </div>
            </div>
            <!-- /.card -->

            
            <!-- /.card -->
          </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <?php $this->load->view('common/footer.php'); ?>