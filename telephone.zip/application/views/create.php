<?php $this->load->view('common/header.php'); ?>
 
 <?php $this->load->view('common/sidebar.php'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add New <a href="<?=base_url('contact')?>" class="btn btn-sm btn-primary"> <i class="fa fa-file-text" aria-hidden="true"></i> View All</a></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add New</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

    <div class="col-md-8">
      <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Add New Contact</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="contact_add" method="post" action="<?=base_url('contact/store')?>" enctype="multipart/form-data" required>
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="inputFirstName">First Name</label>
                    <input type="text" name="first_name" class="form-control" id="inputFirstName" placeholder="First Name" required data-msg-required="First name required">
                  </div>
            

                
                  <div class="form-group">
                    <label for="inputMiddleName">Middle Name</label>
                    <input type="text" name="middle_name" class="form-control" id="inputMiddleName" placeholder="Middle Name" >
                  </div>
               
               
                  <div class="form-group">
                    <label for="inputLastName">Last Name</label>
                    <input type="text" name="last_name" class="form-control" id="inputLastName" placeholder="Last Name"  required data-msg-required="Last name required">
                  </div>
                
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" >
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Mobile</label>
                    <input type="text" name="mobile"  class="form-control" id="inputMobile" placeholder="Mobile">
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Landline</label>
                    <input type="text" name="landline" class="form-control" id="inputLandline" placeholder="Landline">
                  </div>


                  <div class="form-group">
                    <label for="inputPhoto">Photo</label>
                    <input type="file" name="photo" class="form-control view_photo" id="inputPhoto">
                    <div id="file_error" style="color: red;"></div>
                  </div>
                  
                  

                  <div class="form-group">
                    <label for="inputNotes">Notes </label>
                    <textarea name="notes" class="form-control" id="inputNotes" rows="3" placeholder="Notes"></textarea>
                  </div>

                
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Add New Contact</button>
                </div>
              </form>
            </div>
      <!-- /.card -->
    </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <?php $this->load->view('common/footer.php'); ?>