<?php $this->load->view('common/header.php'); ?>
 
 <?php $this->load->view('common/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">


      <?php if (!empty($this->session->flashdata('success'))) { ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
      <p><?php echo $this->session->flashdata('success') ?></p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php } ?>


        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Contact List <a href="<?=base_url('contact/create')?>" class="btn btn-sm btn-success"> <i class="fa fa-plus-circle" aria-hidden="true"></i> Create New</a> </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Contact List</li>
            </ol>
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Contact List</h3>
              </div>


              <div class="card card-secondary">
              <div class="card-header">
                <h3 class="card-title">Search</h3>
              </div>
              <div class="card-body">
              <div class="row">
                <div class="col-lg-8">
                <form action="" method="get">
                  <div class="row">
                  <div class="col-2 col-lg-4">
                    <input type="text" name="name" value="<?=(!empty($this->input->get('name'))) ? $this->input->get('name') : ''?>" class="form-control" placeholder="Name">
                  </div>
                  <div class="col-2 col-lg-4">
                    <input type="text" name="mobile" class="form-control" placeholder="Mobile">
                  </div>
                  <div class="col-2 col-lg-4">
                    <button class="btn btn-md btn-secondary">Search</button>
                    <a href="<?=base_url('contact')?>" class="btn btn-md">Reset</a>
                  </div>
                  </div>
                </form>
                </div>
                  <div class="col-lg-4">
                    <label>Sort By</label>
                    <select name="sort_by" id="sort_by">
                    <option value="">-None-</option>
                      <option value="name" <?php if(!empty($this->input->get('sort_by')) && $this->input->get('sort_by') == 'name') {?> selected <?php } ?>>Name</option>
                      <option value="added_date" <?php if(!empty($this->input->get('sort_by')) && $this->input->get('sort_by') == 'added_date') {?> selected <?php } ?>>Added Date</option>
                  </select>
                  </div>
                </div>


              </div>

              <div class="card-body">
                <div class="row">
                  
                  
                </div>

                
              </div>
              <!-- /.card-body -->
            </div>


              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Added Date</th>
                      <th>No. of Viewed</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php if(!empty($contact)) {
                    
                    $j = 1;
                    foreach($contact as $list){
                    ?>
                    <tr>
                      <td><?=$page+$j;?></td>
                      <td><?=$list['full_name']?></td>
                      <td><?=$list['email']?></td>
                      <td><?=$list['mobile']?></td>
                      <td><?=$list['added_date']?></td>
                      <td><?=$list['no_of_viewed']?></td>
                      <td>
                      <a href='<?=base_url('contact/view/'.$list['id'])?>' id='demo-dt-view-btn' class='btn btn-primary btn-xs add-tooltip' data-toggle='tooltip' data-placement='top' title="View" ><i class='fa fa-eye'></i></a>
                      
                      <a href='<?=base_url('contact/edit/'.$list['id'])?>' id='demo-dt-view-btn' class='btn btn-primary btn-xs add-tooltip' data-toggle='tooltip' data-placement='top' title="Edit" ><i class='fa fa-edit'></i></a>
									
									    <button data-target="#delete_modal" data-toggle="modal" class="btn btn-danger btn-xs add-tooltip" data-toggle="tooltip" data-placement="top" title="Delete" onclick="delete_clients(<?=$list['id']?>)"><i class="fa fa-trash"></i></button></td>
                    </tr>
                    <?php $j++;}  }else{?>

                      <tr>
                        <td colspan="7" align="center"> No Record Found.</td>
                      </tr>

                      <?php } ?>
                    
                   
                  </tbody>
                </table>
              </div>
             
              <?php echo $this->pagination->create_links() ?>
              <!-- /.card-body -->
              
            </div>
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
         
        </div>
        <!-- /.row -->
        
       
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <?php $this->load->view('common/footer.php'); ?>