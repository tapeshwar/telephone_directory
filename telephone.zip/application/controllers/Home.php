<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
    }

	public function index(){
		
        if (empty($this->session->userdata('id'))) {
			redirect(base_url('login'));
			exit();
		}

        $view_data = $this->user_model->views_detail();
        if(!empty($view_data)){
            $view_date = [];
            $view_no = [];
            foreach($view_data as $data){
                $view_date[] = $data['view_date'];
                $view_no[] = $data['t_view'];
            }

        }
        $data_date = "'" . implode ( "', '", $view_date ) . "'";
        $data_view = implode ( ",", $view_no );
        
	
		$data = [
			'title' => 'Dashboard',
			'heading' => 'Dashboard',
            'data_date'=>$data_date,
            'data_view' => $data_view
		];
		
		$this->load->view('dashboard',$data);
	}


}
