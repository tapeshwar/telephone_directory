<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

	public function user_login($data){
        $query = $this->db->query("select * from users where username = '".$data['username']."'");
        $user = $query -> result_array();
        if(!empty($user)){
            $pass = $user[0]['password'];
            if(password_verify($data['password'],$pass)){
                return $query -> result_array();
            }
        }
      
    }

    public function user_registration($post){
        $username = $post['username'];
        $str = $post['password'];
        $options= ['t_salt'=>'fksafsf'];
        $password = password_hash($str, PASSWORD_BCRYPT, $options);

        $email = $post['email'];
        $mobile = $post['mobile'];

        return $this->db->query("insert into users set 
            username = '".$username."',
            password = '".$password."',
            email = '".$email."',
            mobile='".$mobile."',
            attempt = 1,
            status = 1

        
        ");
        
    }

    
    public function add_contact($data){
        if(!empty($data)){
            
            if(!empty($data['middle_name'])){
                $full_name = $data['first_name'].' '.$data['middle_name'].' '.$data['last_name'];
            }else{
                $full_name = $data['first_name'].' '.$data['last_name'];
            }
            return $this->db->insert("contact", array(
                "first_name" => $data['first_name'],
                "middle_name" => $data['middle_name'],
                "last_name" => $data['last_name'],
                "full_name" => $full_name,
                "email" => $data['email'],
                "mobile" => $data['mobile'],
                "landline" => $data['landline'],
                "photo" => $data['photo'],
                "notes" => $data['notes'],
                "added_date" => date('Y-m-d'),
                )
            );
        }
    }


    
    public function get_count($get) {
        if(!empty($get['name'])){
            $this->db->like('full_name', $get['name']);
            return $this->db->get('contact')->num_rows();
        }else if(!empty($get['mobile'])){
            $this->db->like('mobile', $get['mobile']);
            return $this->db->get('contact')->num_rows();
        }else{
            return $this->db->count_all('contact');
        }
        
    }


    public function get_contact($get, $limit, $start){
        $this->db->where("status",1);

        if(!empty($get['name'])){
            $this->db->like('full_name', $get['name']);      
        }
        if(!empty($get['mobile'])){
            $this->db->like('mobile', $get['mobile']);
        }

        if(!empty($get['sort_by']) && $get['sort_by'] == 'name'){
            $this->db->order_by("full_name", "asc");
        }

        if(!empty($get['sort_by']) && $get['sort_by'] == 'added_date'){
            $this->db->order_by("added_date", "asc");
        }

        $this->db->limit($limit, $start);
        $this->db->order_by("id", "desc");
        $query = $this->db->get('contact');
        return $query->result_array();
    }

    function delete_contact($id){
        if(!empty($id)){
             $this->db->where("id", $id)->delete("contact");
             return true;
         }else{
             return false;
         }
      
      }



    public function edit_contact($id){
        $this->db->where('id',$id);
        $query = $this->db->get('contact');
        return $query->result_array();

    }

    public function update_views($id){
        $this->db->set('no_of_viewed', 'no_of_viewed+1', FALSE);
        $this->db->where('id', $id);
        $this->db->update('contact');

    }

    public function check_views_per_day($contact_id, $today){
        $this->db->where('contact_id', $contact_id);
        $this->db->where('view_date',  $today);
        return $this->db->get('contact_view')->num_rows();
        
    }

    public function update_views_per_day($contact_id, $today){
        $this->db->set('view_no', 'view_no+1', FALSE);
        $this->db->where('contact_id', $contact_id);
        $this->db->where('view_date',  $today);
        $this->db->update('contact_view');

    }

    public function insert_views_per_day($contact_id, $today){
        return $this->db->insert("contact_view", array(
            "contact_id" => $contact_id,
            "view_date" => $today,
            "view_no" => 1,
            )
        );

    }
    

    public function get_total_view(){
        $data=$this->db
        ->select_sum('no_of_viewed')
        ->from('contact')
         ->order_by('price desc')
        ->limit(3)
        ->get();
       
    return $data->result_array();
    }



public function update_contact($data, $id){
    if(!empty($data)){
        
        if(!empty($data['middle_name'])){
            $full_name = $data['first_name'].' '.$data['middle_name'].' '.$data['last_name'];
        }else{
            $full_name = $data['first_name'].' '.$data['last_name'];
        }

        $data = array(
            "first_name" => $data['first_name'],
            "middle_name" => $data['middle_name'],
            "last_name" => $data['last_name'],
            "full_name" => $full_name,
            "email" => $data['email'],
            "mobile" => $data['mobile'],
            "landline" => $data['landline'],
            "photo" => $data['photo'],
            "notes" => $data['notes'],
            "updated_date" => date('Y-m-d'),
        );

        $this->db->where('id', $id);
        return $this->db->update('contact', $data);
    }
}



public function views_detail(){
    $sql = "SELECT
    DATE(view_date) AS `view_date`,
    SUM(view_no) AS t_view
    FROM
    contact_view
    WHERE
    view_date >=  CURRENT_DATE - INTERVAL 6 DAY
    GROUP BY
    DATE(view_date)";
   
    $query = $this->db->query($sql);
    return $query -> result_array();
    
  
}


public function views_by_day($contact_id){
    $sql = "SELECT
    DATE(view_date) AS `view_date`,
    SUM(view_no) AS t_view
    FROM
    contact_view
    WHERE
    view_date >=  CURRENT_DATE - INTERVAL 6 DAY AND contact_id = $contact_id
    GROUP BY
    DATE(view_date)";
   
    $query = $this->db->query($sql);
    return $query -> result_array();
    
  
}

}


?>