-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2022 at 12:17 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `telephone`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `landline` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `added_date` date NOT NULL,
  `updated_date` date DEFAULT NULL,
  `no_of_viewed` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `first_name`, `middle_name`, `last_name`, `full_name`, `email`, `mobile`, `landline`, `photo`, `notes`, `added_date`, `updated_date`, `no_of_viewed`, `status`) VALUES
(1, 'Narotham', 'Jay', 'Singh', 'Narotham Jay Singh', 'test@test.com', '9332523432', '3243242343', '1662714545files.png', 'test', '2022-09-10', NULL, 13, 1),
(2, 'Mayank', '', 'kumar', 'Mayank kumar', 'test@fefsaf.sdfa', '2424234234', '2342342342', '1662715723FCE.png', 'sdfsafasfs', '2022-09-10', NULL, 9, 1),
(3, 'Shushila', '', 'Mishra', 'Shushila Mishra', 'shushila@fefsaf.sdfa', '2424234234', '2342342342', '1662715801FCE.png', 'sdfsafasfs', '2022-09-10', NULL, 9, 1),
(5, 'Tarun', '', 'Singh', 'Tarun Singh', 'tarun@esfsd.com', '3454353453', '4354354354', '1662721277FCE.png', 'sdfsaf', '2022-09-10', NULL, 14, 1),
(6, 'Tapesh', '', 'Pandit', 'Tapesh Pandit', 'tapeshwartoday@gmail.com', '9798989808', '0989089080', '', 'tdfa fafafsf', '2022-09-05', NULL, 8, 1),
(7, 'Ramesht', 'Kumart', 'Panditt', 'Ramesht Kumart Panditt', 'ramesh@yopmatil.com', '7989079736', '3324839344', '1662727395FCE.png', 'etr  tq tq tq', '2022-09-09', NULL, 11, 1),
(8, 'Kavita', '', 'Mishra', 'Kavita Mishra', 'kk@yopmail.com', '8789654321', '0237654321', '1662780529Qiam-Consulting-Inc.png', 'test', '2022-09-04', NULL, 19, 1),
(9, 'Chandan', '', 'Kumar', 'Chandan Kumar', 'chandan@yopmail.com', '9834894932', '3434324324', '1662793707Banner-BitRaser-Enterprise-Page.jpg', '', '2022-09-10', NULL, 11, 1),
(13, 'Pradip', '', 'kumar', 'Pradip kumar', 'tusakjsdk@yopmail.com', '9876544335', '66777676767', '1662798589FCE.png', 'test', '2022-09-10', NULL, 7, 1),
(21, 'Jitendra', 'kumar', 'singh', 'Jitendra kumar singh', 'zz@sdfds.cssds', '9890987654', '78787878097', '1662801406KPMG---Middle-East.png', 'tests', '2022-09-10', '2022-09-10', 35, 1),
(22, 'Naresh', '', 'kumar', 'Naresh kumar', 'test@naresh.in', '9876548967', '', '1662802115Prosper-Market-Place.png', '', '2022-09-10', '2022-09-10', 26, 1),
(23, 'Devendra', 'Kumar', 'Singh', 'Devendra Kumar Singh', 'devkumar@yopmail.com', '9878878729', '08898983473', '1663063814SMS-Infocomm.png', 'test test', '2022-09-13', '2022-09-13', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_view`
--

CREATE TABLE `contact_view` (
  `id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `view_date` date NOT NULL,
  `view_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contact_view`
--

INSERT INTO `contact_view` (`id`, `contact_id`, `view_date`, `view_no`) VALUES
(1, 5, '2022-09-10', 5),
(2, 7, '2022-09-10', 3),
(3, 8, '2022-09-10', 4),
(4, 5, '2022-09-09', 3),
(5, 8, '2022-09-09', 3),
(6, 8, '2022-09-04', 6),
(7, 7, '2022-09-04', 2),
(8, 6, '2022-09-04', 2),
(9, 5, '2022-09-04', 1),
(10, 3, '2022-09-04', 2),
(11, 2, '2022-09-04', 1),
(12, 1, '2022-09-04', 1),
(13, 8, '2022-09-05', 1),
(14, 7, '2022-09-05', 1),
(15, 6, '2022-09-05', 1),
(16, 5, '2022-09-05', 1),
(17, 3, '2022-09-05', 1),
(18, 2, '2022-09-05', 1),
(19, 1, '2022-09-05', 1),
(20, 8, '2022-09-06', 1),
(21, 7, '2022-09-06', 1),
(22, 6, '2022-09-06', 1),
(23, 5, '2022-09-06', 1),
(24, 3, '2022-09-06', 1),
(25, 2, '2022-09-06', 1),
(26, 1, '2022-09-06', 1),
(27, 8, '2022-09-07', 1),
(28, 7, '2022-09-07', 1),
(29, 6, '2022-09-07', 1),
(30, 5, '2022-09-07', 1),
(31, 3, '2022-09-07', 1),
(32, 2, '2022-09-07', 1),
(33, 1, '2022-09-07', 1),
(34, 8, '2022-09-08', 1),
(35, 7, '2022-09-08', 1),
(36, 6, '2022-09-08', 1),
(37, 5, '2022-09-08', 1),
(38, 3, '2022-09-08', 1),
(39, 2, '2022-09-08', 1),
(40, 1, '2022-09-08', 1),
(41, 7, '2022-09-09', 1),
(42, 6, '2022-09-09', 1),
(43, 3, '2022-09-09', 1),
(44, 2, '2022-09-09', 1),
(45, 1, '2022-09-09', 1),
(46, 6, '2022-09-10', 1),
(47, 3, '2022-09-10', 2),
(48, 2, '2022-09-10', 2),
(49, 1, '2022-09-10', 1),
(50, 4, '2022-09-10', 1),
(51, 9, '2022-09-10', 2),
(52, 22, '2022-09-10', 6),
(53, 21, '2022-09-10', 1),
(54, 22, '2022-09-11', 19),
(55, 8, '2022-09-11', 2),
(56, 1, '2022-09-11', 6),
(57, 2, '2022-09-11', 1),
(58, 21, '2022-09-11', 34),
(59, 13, '2022-09-11', 6),
(60, 9, '2022-09-11', 9),
(61, 7, '2022-09-11', 1),
(62, 22, '2022-09-13', 1),
(63, 13, '2022-09-13', 1),
(64, 5, '2022-09-13', 1),
(65, 23, '2022-09-13', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `attempt` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `mobile`, `attempt`, `status`) VALUES
(1, 'admin', '$2y$10$wdYzUbG4zxezt8OfLrLV5exlAw0wJQoFEJ9jSGCCOqSIusv2ECfgu', 'tapeshwartoday@gmail.com', '9717102772', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_view`
--
ALTER TABLE `contact_view`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `contact_view`
--
ALTER TABLE `contact_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
