<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->library('upload');
		$this->load->library('pagination');
    }

	public function index(){
		
        if (empty($this->session->userdata('id'))) {
			redirect(base_url('login'));
			exit();
		}

			$get = $this->input->get();
			if(!empty($get['name'])){
				$get['name'] = $get['name'];
			}

			if(!empty($get['name'])){
				$get['mobile'] = $get['mobile'];
			}

			if(!empty($get['sort_by'])){
				$get['sort_by'] = $get['sort_by'];
			}
		

			$config['base_url'] = base_url('contact/index');
			$config['total_rows'] = $this->user_model->get_count($get);
			$config['per_page'] = '10';
			$config['uri_segment'] = 2;
			$config["use_page_numbers"] = TRUE;
			$config['num_links'] = "16";
			$config['full_tag_open'] = '<ul class="pagination" style="justify-content: center;">';        
			$config['full_tag_close'] = '</ul>';        
			$config['first_link'] = 'First';        
			$config['last_link'] = 'Last';        
			$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';        
			$config['first_tag_close'] = '</span></li>';        
			$config['prev_link'] = 'Previous';        
			$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';        
			$config['prev_tag_close'] = '</span></li>';        
			$config['next_link'] = 'Next';        
			$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';        
			$config['next_tag_close'] = '</span></li>';        
			$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';        
			$config['last_tag_close'] = '</span></li>';        
			$config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';        
			$config['cur_tag_close'] = '</a></li>';        
			$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';        
			$config['num_tag_close'] = '</span></li>';
			$config['enable_query_strings'] = TRUE;
			$config['page_query_string'] = TRUE;
			$config['use_page_numbers'] = TRUE;
			$config['reuse_query_string'] = TRUE;
			$config['query_string_segment'] = 'page';

			$this->pagination->initialize($config);

			$offset = ($this->input->get('page')) ? ( ( $this->input->get('page') - 1 ) * $config["per_page"] ) : 0;
			//$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			//$start = ($page - 1) * $config["per_page"];


			$contact = $this->user_model->get_contact($get, $config["per_page"], $offset);
	
		$data = [
			'page' => $offset,
			'title' => 'Contact List',
			'heading' => 'Contact List',
			'contact' => (!empty($contact)) ? $contact : NULL,
		];
		
		$this->load->view('list',$data);
	}

	public function create(){

		$data = [
			'title' => 'New Contact',
			'heading' => 'New Contact',
		];
		
		$this->load->view('create',$data);

	}

	public function store(){
		if(!empty($this->input->post())){
			$post = $this->input->post();

			$uploaded_file = '';
			if(!empty($_FILES['photo']['name'])){	
				$this->load->library('upload');
				$thumb_name = time()."".str_replace(str_split(' ()\\/,:*?"<>|'),'',$_FILES['photo']['name']);
				$config = array();
				$config['upload_path']="asset/photo/";
				$config['allowed_types']='jpg|png|jpeg';
				$config['file_name'] = $thumb_name;
				$config['max_size']  = '500';
				$this->upload->initialize($config);
					if($this->upload->do_upload('photo')){
						$uploadData = $this->upload->data();
						//echo '<pre>';
						//print_r($uploadData);
						$uploaded_file = $uploadData['file_name'];
						//echo $uploaded_file;
						//die;
					}else{
						$this->upload->display_errors();
						echo json_encode(['status'=>'error', 'msg'=>'File size must be below 500kb only.']);
						exit();
					}
				}
			
			$post['photo'] = $uploaded_file;
			$result=$this->user_model->add_contact($post);
			
			if($result){
				$this->session->set_flashdata('success', 'Data Inserted Successfully.');
				echo json_encode(['status'=>'success', 'url'=>'index']);
				exit();
			}
			
		}

	}


	public function delete($id){
		
		$result=$this->user_model->delete_contact($id);
		if ($result) {
			$this->session->set_flashdata('success', 'Data deleted successfully');
		}
		
	}


	public function edit($id){

		$contact = $this->user_model->edit_contact($id);

		$data = [
			'title' => 'Edit Contact',
			'heading' => 'Edit Contact',
			'contact' => (!empty($contact)) ? $contact[0] : NULL,
		];
		
		$this->load->view('edit',$data);

	}



	public function update(){
		if(!empty($this->input->post())){
			$post = $this->input->post();

			$uploaded_file = '';
			if(!empty($_FILES['photo']['name'])){	
				$this->load->library('upload');
				$thumb_name = time()."".str_replace(str_split(' ()\\/,:*?"<>|'),'',$_FILES['photo']['name']);
				$config = array();
				$config['upload_path']="asset/photo/";
				$config['allowed_types']='jpg|png|jpeg';
				$config['file_name'] = $thumb_name;
				$config['max_size']  = '500';
				$this->upload->initialize($config);
					if($this->upload->do_upload('photo')){
						$uploadData = $this->upload->data();
						//echo '<pre>';
						//print_r($uploadData);
						$uploaded_file = $uploadData['file_name'];
						//echo $uploaded_file;
						//die;
					}else{
						$this->upload->display_errors();
						echo json_encode(['status'=>'error', 'msg'=>'File size must be below 500kb only.']);
						exit();
					}

					$post['photo'] = $uploaded_file;
				}else{
					$post['photo'] = $this->input->post('saved_photo');
				}	
				
				$id = $this->input->post('eid');
			
			$result=$this->user_model->update_contact($post,$id);
			
			if($result){
				$this->session->set_flashdata('success', 'Data Updated Successfully.');
				echo json_encode(['status'=>'success', 'url'=>base_url('contact')]);
				exit();
			}
			
		}

	}


	public function view($id){

		$today = date('2022-09-10');//die;

		$contact = $this->user_model->edit_contact($id);
		$update_views = $this->user_model->update_views($id);

		$check_views_per_day = $this->user_model->check_views_per_day($id, $today);
		if($check_views_per_day>0){
			$update_views_per_day = $this->user_model->update_views_per_day($id, $today);
		}else{
			$insert_views_per_day = $this->user_model->insert_views_per_day($id, $today);
		}

		//echo '<pre>';
		//print_r($check_views_per_day);die;

		

		$data = [
			'title' => 'View Contact',
			'heading' => 'View Contact',
			'contact' => (!empty($contact)) ? $contact[0] : NULL,
		];
		
		$this->load->view('view',$data);

	}


}
