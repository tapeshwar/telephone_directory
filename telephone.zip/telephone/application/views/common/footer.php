<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2014-2022 <a href="#">Testing</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>
</div>
<!-- ./wrapper -->








<div class="modal fade" id="delete_modal" admins="dialog" tabindex="-1" aria-labelledby="delete_modal" aria-hidden="true">
    <div class="modal-dialog" style="width: 400px;">
        <div class="modal-content">
            <!--Modal header-->
            <div class="modal-header" style="display: block">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">Confirm delete</h4>
            </div>
           	<!--Modal body-->
            <div class="modal-body">
            	<p>Are you sure you want to delete this data?</p>
            	<div class="text-right">
            		<button data-dismiss="modal" class="btn btn-default btn-sm" type="button" id="modal_close">Close</button>
                	<button class="btn btn-danger btn-sm" id="delete_client" value="">Delete</button>
            	</div>
            </div>
           
        </div>
    </div>
</div>








<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?=base_url('asset/js/jquery.min.js')?>"></script>
<!-- Bootstrap -->
<script src="<?=base_url('asset/js/bootstrap.bundle.min.js')?>"></script>
<!-- Admin-->
<script src="<?=base_url('asset/js/custom.js')?>"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?=base_url('asset/chart.js/Chart.min.js')?>"></script>
<script src="<?=base_url('asset/js/demo.js')?>"></script>
<script src="<?=base_url('asset/js/jquery.validate.js')?>"></script>
<script src="<?=base_url('asset/js/myscript.js')?>"></script>

<script>
	function delete_clients(id){
	    $("#delete_client").val(id);
	}

	$("#delete_client").click(function(){
    	$.ajax({
		    url: "<?=base_url()?>contact/delete/"+$("#delete_client").val(),
		    success: function(response) {
				window.location.href = "<?=base_url('contact')?>";
		    },
			fail: function (error) {
			    alert(error);
			}
		});
    })

</script>

<script>


$(function () {
  'use strict'

  var ticksStyle = {
    fontColor: '#495057',
    fontStyle: 'bold'
  }

  var mode = 'index'
  var intersect = true

  var $visitorsChart = $('#visitors-chart')

  var visitorsChart = new Chart($visitorsChart, {
    data: {
      labels: [<?=$data_date?>],
      datasets: [{
        type: 'line',
        data: [<?=$data_view?>],
        backgroundColor: 'transparent',
        borderColor: '#007bff',
        pointBorderColor: '#007bff',
        pointBackgroundColor: '#007bff',
        fill: false
        // pointHoverBackgroundColor: '#007bff',
        // pointHoverBorderColor    : '#007bff'
      },
      ]
    },
    options: {
      maintainAspectRatio: false,
      tooltips: {
        mode: mode,
        intersect: intersect
      },
      hover: {
        mode: mode,
        intersect: intersect
      },
      legend: {
        display: false
      },
      scales: {
        yAxes: [{
          // display: false,
          gridLines: {
            display: true,
            lineWidth: '4px',
            color: 'rgba(0, 0, 0, .2)',
            zeroLineColor: 'transparent'
          },
          ticks: $.extend({
            beginAtZero: true,
            suggestedMax: 200
          }, ticksStyle)
        }],
        xAxes: [{
          display: true,
          gridLines: {
            display: false
          },
          ticks: ticksStyle
        }]
      }
    }
  })
})


</script>
</body>
</html>
