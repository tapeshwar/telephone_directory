<?php $this->load->view('common/header.php'); ?>
 
 <?php $this->load->view('common/sidebar.php'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>View Contact <a href="<?=base_url('contact')?>" class="btn btn-sm btn-primary"> <i class="fa fa-list"> </i> View All</a></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">View Contact</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

    <div class="col-md-8">
      <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">View Contact</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="contact_edit" method="post" action="<?=base_url('contact/update')?>" enctype="multipart/form-data" required>
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="inputFirstName">First Name: </label>
                    <?=(!empty($contact['first_name'])) ? $contact['first_name'] : '' ?>
                  </div>
            

                
                  <div class="form-group">
                    <label for="inputMiddleName">Middle Name: </label>
                    <?=(!empty($contact['middle_name'])) ? $contact['middle_name'] : '' ?>
                  </div>
               
               
                  <div class="form-group">
                    <label for="inputLastName">Last Name: </label>
                    <?=(!empty($contact['last_name'])) ? $contact['last_name'] : '' ?>
                  </div>
                
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address: </label>
                    <?=(!empty($contact['email'])) ? $contact['email'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Mobile: </label>
                    value="<?=(!empty($contact['mobile'])) ? $contact['mobile'] : '' ?>
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Landline: </label>
                    <?=(!empty($contact['landline'])) ? $contact['landline'] : '' ?>
                  </div>


                  <div class="form-group">
                    <label for="inputPhoto">Photo: </label>
                    <?php if(!empty($contact['photo'])) {?>
                    <span><img src="<?=base_url('asset/photo/'.$contact['photo'])?>" height="20" alt="Photo"></span>
                  <?php } ?>
                  </div>
                

                  <div class="form-group">
                    <label for="inputNotes">Notes: </label>
                    <?=(!empty($contact['notes'])) ? $contact['notes'] : '' ?>
                  </div>

                
                </div>
                <!-- /.card-body -->

               
              </form>
            </div>
      <!-- /.card -->
    </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <?php $this->load->view('common/footer.php'); ?>