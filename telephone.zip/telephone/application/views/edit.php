<?php $this->load->view('common/header.php'); ?>
 
 <?php $this->load->view('common/sidebar.php'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Contact <a href="<?=base_url('contact')?>" class="btn btn-sm btn-primary"> <i class="fa fa-list"> </i> View All</a></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Contact</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

    <div class="col-md-8">
      <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Edit Contact</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="contact_edit" method="post" action="<?=base_url('contact/update')?>" enctype="multipart/form-data" required>
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="inputFirstName">First Name</label>
                    <input type="text" name="first_name" class="form-control" id="inputFirstName" placeholder="First Name" required data-msg-required="First name required" value="<?=(!empty($contact['first_name'])) ? $contact['first_name'] : '' ?>">
                  </div>
            

                
                  <div class="form-group">
                    <label for="inputMiddleName">Middle Name</label>
                    <input type="text" name="middle_name" class="form-control" id="inputMiddleName" placeholder="Middle Name"  value="<?=(!empty($contact['middle_name'])) ? $contact['middle_name'] : '' ?>">
                  </div>
               
               
                  <div class="form-group">
                    <label for="inputLastName">Last Name</label>
                    <input type="text" name="last_name" class="form-control" id="inputLastName" placeholder="Last Name"  required data-msg-required="Last name required" value="<?=(!empty($contact['last_name'])) ? $contact['last_name'] : '' ?>">
                  </div>
                
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="<?=(!empty($contact['email'])) ? $contact['email'] : '' ?>">
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Mobile</label>
                    <input type="text" name="mobile" class="form-control" id="inputMobile" placeholder="Mobile" value="<?=(!empty($contact['mobile'])) ? $contact['mobile'] : '' ?>">
                  </div>

                  <div class="form-group">
                    <label for="inputLastName">Landline</label>
                    <input type="text" name="landline" class="form-control" id="inputLandline" placeholder="Landline" value="<?=(!empty($contact['landline'])) ? $contact['landline'] : '' ?>">
                  </div>


                  <div class="form-group">
                    <label for="inputPhoto">Photo</label>
                    <input type="file" name="photo" class="form-control view_photo" id="inputPhoto">
                    <?php if(!empty($contact['photo'])) {?>
                    <span><img src="<?=base_url('asset/photo/'.$contact['photo'])?>" height="20" alt="Photo"></span>
                    <input type="hidden" name="saved_photo" value="<?=$contact['photo']?>">
                  <?php } ?>
                  </div>
                  
                
                  <div class="form-group">
                    <label for="inputNotes">Notes </label>
                    <textarea name="notes" class="form-control" id="inputNotes" rows="3" placeholder="Notes"><?=(!empty($contact['notes'])) ? $contact['notes'] : '' ?></textarea>
                  </div>

                
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                <input type="hidden" name="eid" value="<?=$contact['id']?>">
                  <button type="submit" class="btn btn-primary">Update Contact</button>
                </div>
              </form>
            </div>
      <!-- /.card -->
    </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <?php $this->load->view('common/footer.php'); ?>