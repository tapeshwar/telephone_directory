$(document).ready(function(){


   
    $('#user_login_form').validate({
        submitHandler:function(form){
            var btn = $('user_login_btn');
            $.ajax({
                type: "post",
                url: $('#user_login_form').attr('data-url'),
                data: new FormData($('#user_login_form')[0]),
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (r) {    
                    if(r.status == 'success'){
                        window.location.href=r.url;
                        return false;
                    }
                    else if(r.status == 'error'){
                        $('#error').html(r.msg)
                        return false;
                    }else{
                        console.log(r.msg);
                        
                    }
                }
            });
    
        }
    })


    /* jQuery.validator.addMethod("validate_email", function(value, element) {

        if (/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value)) {
            return true;
        } else {
            return false;
        }
    }, "Please enter a valid Email."); */


    jQuery.validator.addMethod("validate_email", function(value, element) {

        return this.optional(element) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
    }, "Please enter a valid Email");

   


    jQuery.validator.addMethod("validate_mobile", function (phone_number, element) {
        phone_number = phone_number.replace(/\s+/g, "");
        return this.optional(element) || phone_number.length > 9 &&
              phone_number.match(/^\(?[\d\s]{3}[\d\s]{3}[\d\s]{4}$/);
    }, "Invalid mobile number");


    jQuery.validator.addMethod("validate_landline", function (phone_number, element) {
        phone_number = phone_number.replace(/\s+/g, "");
        return this.optional(element) || phone_number.length > 10 &&
              phone_number.match(/^\(?[\d\s]{3}[\d\s]{3}[\d\s]{5}$/);
    }, "Invalid landline number");



    $('#contact_add').validate({
        rules: {
            email: {
                validate_email: true
            },
            mobile: {
                validate_mobile: true
            },
            landline: {
                validate_landline: true
            },
        },
        submitHandler:function(form){
            //var btn = $('user_login_btn');
            $.ajax({
                type: "post",
                url: $('#contact_add').attr('action'),
                data: new FormData($('#contact_add')[0]),
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (r) {    
                    if(r.status == 'success'){
                        window.location.href=r.url;
                        return false;
                    }else if(r.status == 'error'){
                        $('#file_error').html(r.msg)
                        return false;
                    }
                }
            });
    
        }
    })



    $('#contact_edit').validate({
        rules: {
            email: {
                validate_email: true
            },
            mobile: {
                validate_mobile: true
            },
            landline: {
                validate_landline: true
            },
        },
        submitHandler:function(form){
            $.ajax({
                type: "post",
                url: $('#contact_edit').attr('action'),
                data: new FormData($('#contact_edit')[0]),
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (r) {    
                    if(r.status == 'success'){
                        window.location.href=r.url;
                        return false;
                    }
                }
            });
    
        }
    })


    $(document).on('change','#sort_by', function(){
        var sort_by = $(this).val();
        if(sort_by!=''){
            window.location.href='?sort_by='+sort_by;
        }else{
            window.location.href='contact';
        }    
    })
    
    })



    $(document).ready(function(){ 
        $(document).on("keydown", ".mask_mobile", function(e) { 
            var key = e.charCode || e.keyCode || 0;
            var mobile = $(this);
            if (key !== 8 && key !== 9) {
                if (mobile.val().mobile === 5) {
                  //mobile.val(mobile.val() + ' ');
               }  
            }
            return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));	
        }).bind('focus click', function () {
            var mobile = $(this);
            var val = mobile.val();
            mobile.val('').val(val); 
        });     
        
        
        $(document).on("keydown", ".mask_pincode", function(e) { 
            var key = e.charCode || e.keyCode || 0;
            var pincode = $(this);
            if (key !== 8 && key !== 9) {
                if (pincode.val().length === 5) {
                  //pincode.val(pincode.val() + ' ');
               }  
            }
            return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));	
        }).bind('focus click', function () {
            var pincode = $(this);
            var val = pincode.val();
            pincode.val('').val(val); 
        });
    
        
      })


    $(document).ready(function(){ 
      function view_uploaded_img(t) {
        if ($(t).parent().children().is('div.show_images')) {
        $(t).parent().children('.show_images').html('');
        } else {
        $(t).after('<div class="show_images"></div>');
        }
        var files = t.files;
        for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var imageType = /image.*/;
        if (!file.type.match(imageType)) {
            continue;
        }
        var imgId = 'show_img_' + Math.random() + i;
        $(t).parent().children('.show_images').append('<img id="' + imgId + '" src="">');
        var img = document.getElementById(imgId);
        img.file = file;
        var reader = new FileReader();
        reader.onload = (function (aImg) {
            return function (e) {
            aImg.src = e.target.result;
            };
        })(img);
        reader.readAsDataURL(file);
        }
    }
    $(document).on('change', '.view_photo', function () {
        view_uploaded_img(this);
    });

})

$(document).ready(function(){
function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  }
  $(document).on('keyup', '.mobile', function () {
    isEmail(this);
});

})